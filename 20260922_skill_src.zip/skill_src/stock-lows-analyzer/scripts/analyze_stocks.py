import os
import sys
import json
import datetime
import re
import requests
import pandas as pd
from pathlib import Path
import time
from filelock import FileLock

# Try to import yfinance, handle missing library gracefully
try:
    import yfinance as yf
except ImportError:
    print("Error: 'yfinance' library not found. Please install it using 'pip install yfinance'.")
    sys.exit(1)

PROJECT_ROOT = Path(__file__).resolve().parents[3]

CACHE_DIR = PROJECT_ROOT / "CACHE" / "stock_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_DIR = PROJECT_ROOT / "OUTPUT"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def get_cache_path(symbol):
    return CACHE_DIR / f"{symbol.upper()}.json"

def fetch_public_rating(symbol):
    """Fetch analyst recommendation from Public.com."""
    urls = [
        f"https://public.com/stocks/{symbol.lower()}/forecast-price-target",
        f"https://public.com/stocks/{symbol.lower()}"
    ]
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.31"
    }
    
    for url in urls:
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code != 200:
                continue
            
            pattern = r'<script id="__NEXT_DATA__" type="application/json"[^>]*>(.*?)</script>'
            match = re.search(pattern, response.text)
            if not match:
                continue
                
            data = json.loads(match.group(1))
            
            # Try different possible paths for recommendation
            paths = [
                ['props', 'pageProps', 'instrumentData', 'recommendation'],
                ['props', 'pageProps', 'instrumentData', 'instrumentCompanyDetails', 'recommendation'],
                ['props', 'pageProps', 'initialState', 'asset', 'assetInfo', 'recommendation']
            ]
            
            rec = None
            for path in paths:
                curr = data
                try:
                    for key in path:
                        curr = curr[key]
                    rec = curr
                    if rec: break
                except (KeyError, TypeError):
                    continue
                    
            if rec:
                rating_num = rec.get('currentConsensusRating')
                if rating_num is not None:
                    try:
                        num = float(rating_num)
                        if num <= 1.5: return "Strong Buy"
                        if num <= 2.5: return "Buy"
                        if num <= 3.5: return "Hold"
                        if num <= 4.5: return "Sell"
                        return "Strong Sell"
                    except (ValueError, TypeError):
                        pass
        except Exception as e:
            print(f"Error fetching Public rating for {symbol} at {url}: {e}")
            
    return None

def fetch_data(symbol, period="max"):
    """Fetch historical data and update cache."""
    cache_path = get_cache_path(symbol)
    
    if cache_path.exists():
        mtime = datetime.datetime.fromtimestamp(cache_path.stat().st_mtime)
        if datetime.datetime.now() - mtime < datetime.timedelta(hours=24):
            with open(cache_path, 'r', encoding='utf-8') as f:
                cached = json.load(f)
                # Ensure all metadata fields are present, otherwise re-fetch
                if all(k in cached for k in ['name', 'description', 'website', 'expectation_value', 'public_rating']) and len(cached.get('history', [])) > 0:
                    return cached

    try:
        ticker = yf.Ticker(symbol)
        hist = ticker.history(period=period)
        if hist.empty:
            return None
        
        info = ticker.info
        company_name = info.get('longName') or info.get('shortName') or symbol.upper()
        
        public_rating = fetch_public_rating(symbol)
        
        data = {
            "symbol": symbol.upper(),
            "name": company_name,
            "description": info.get('longBusinessSummary', "No description available."),
            "website": info.get('website', ""),
            "expectation_value": round(float(info['targetMeanPrice']), 2) if info.get('targetMeanPrice') else None,
            "public_rating": public_rating,
            "last_price": round(float(hist['Close'].iloc[-1]), 2),
            "history": [
                {"date": str(d.date()), "close": round(float(c), 2), "high": round(float(h), 2), "low": round(float(l), 2)} 
                for d, c, h, l in zip(hist.index, hist['Close'], hist['High'], hist['Low'])
            ],
            "updated_at": str(datetime.datetime.now())
        }
        
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        return data
    except Exception as e:
        print(f"Error fetching {symbol}: {e}")
        return None

def fetch_live_info(symbols):
    """Fetch latest intraday data including off-hours in one batch."""
    if not symbols:
        return {}
    try:
        print(f"Fetching live intraday data for {len(symbols)} symbols...")
        # Use 5m interval for intraday data
        data = yf.download(symbols, period="1d", interval="5m", prepost=True, progress=False)
        if data.empty:
            return {}
        
        live_info = {}
        
        def process_series(close_series, high_series, low_series):
            if close_series.empty: return None
            price = round(float(close_series.iloc[-1]), 2)
            intraday = []
            for t, p in close_series.items():
                is_reg = False
                try:
                    # yfinance returns UTC timestamps; convert to US/Eastern (market time)
                    local_time = t.tz_convert('America/New_York') if hasattr(t, 'tz_convert') and t.tzinfo else t
                    h, m = local_time.hour, local_time.minute
                    if (h > 9 or (h == 9 and m >= 30)) and h < 16:
                        is_reg = True
                    time_str = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    time_str = str(t)
                
                intraday.append({"time": time_str, "price": round(float(p), 2), "is_regular": is_reg})
                
            return {
                "price": price,
                "intraday": intraday,
                "high": round(float(high_series.max()), 2),
                "low": round(float(low_series.min()), 2),
                "is_last_regular": intraday[-1]["is_regular"] if intraday else True
            }

        if len(symbols) > 1:
            for sym in symbols:
                sym_up = sym.upper()
                try:
                    res = process_series(data['Close'][sym_up].dropna(), data['High'][sym_up], data['Low'][sym_up])
                    if res: live_info[sym_up] = res
                except: continue
        else:
            sym = symbols[0].upper()
            try:
                # yf.download returns a MultiIndex even for single symbol if symbols is a list
                if isinstance(data.columns, pd.MultiIndex):
                    res = process_series(data['Close'][sym].dropna(), data['High'][sym], data['Low'][sym])
                else:
                    res = process_series(data['Close'].dropna(), data['High'], data['Low'])
                if res: live_info[sym] = res
            except Exception as e:
                print(f"Error processing single symbol {sym}: {e}")
            
        return live_info
    except Exception as e:
        print(f"Error fetching live prices: {e}")
        return {}

def fetch_option_premium(symbol, current_price):
    """Fetch ATM Call premium for expiry nearest to 30 days."""
    try:
        ticker = yf.Ticker(symbol)
        options = ticker.options
        if not options:
            return None
        
        today = datetime.date.today()
        target_date = today + datetime.timedelta(days=30)
        best_expiry = min(options, key=lambda x: abs(datetime.datetime.strptime(x, "%Y-%m-%d").date() - target_date))
        
        chain = ticker.option_chain(best_expiry)
        calls = chain.calls
        
        calls['diff'] = (calls['strike'] - current_price).abs()
        atm_call = calls.sort_values('diff').iloc[0]
        
        return {
            "premium": round(float(atm_call['lastPrice']), 2),
            "strike": round(float(atm_call['strike']), 2),
            "expiry": best_expiry
        }
    except Exception as e:
        print(f"Error fetching options for {symbol}: {e}")
        return None

def calculate_lows(data, live_info=None):
    history = data['history']
    current_price = live_info['price'] if live_info else data['last_price']
    
    def get_period_stats(days):
        cutoff = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
        relevant = [h for h in history if h['date'] >= cutoff]
        if not relevant: return None
        
        highs = [h.get('high', h['close']) for h in relevant]
        lows = [h.get('low', h['close']) for h in relevant]
        p_high = max(max(highs), current_price)
        p_low = min(min(lows), current_price)
        
        vol = (p_high / p_low - 1) * 100 if p_low > 0 else 0
        pos_pct = (current_price - p_low) / (p_high - p_low) * 100 if p_high > p_low else 0
        max_cur_pct = (p_high / current_price - 1) * 100 if current_price > 0 else 0.0
        
        return {"high": p_high, "low": p_low, "vol": vol, "pos_pct": pos_pct, "max_cur_pct": max_cur_pct}

    period_1d = None
    if live_info:
        p_high, p_low = live_info['high'], live_info['low']
        vol = (p_high / p_low - 1) * 100 if p_low > 0 else 0
        pos_pct = (current_price - p_low) / (p_high - p_low) * 100 if p_high > p_low else 0
        max_cur_pct = (p_high / current_price - 1) * 100 if current_price > 0 else 0.0
        period_1d = {"high": p_high, "low": p_low, "vol": vol, "pos_pct": pos_pct, "max_cur_pct": max_cur_pct}

    return {
        "symbol": data["symbol"],
        "data": data,
        "current": current_price,
        "intraday": live_info['intraday'] if live_info else [],
        "is_off_hour": live_info is not None and not live_info.get('is_last_regular', True),
        "regular_close": data['last_price'],
        "expectation_value": data.get("expectation_value"),
        "3y": get_period_stats(3 * 365),
        "1y": get_period_stats(365),
        "6m": get_period_stats(180),
        "3m": get_period_stats(90),
        "7d": get_period_stats(7),
        "1d": period_1d
    }

def generate_html_report(results, output_path=None):
    now = datetime.datetime.now()
    if output_path is None:
        filename = f"stock_report_{now.strftime('%Y%m%d_%H%M%S')}.html"
        output_path = OUTPUT_DIR / filename
    else:
        output_path = Path(output_path)

    thresholds = {
        "3y": {"low": 15, "high": 95},
        "1y": {"low": 15, "high": 95},
        "6m": {"low": 15, "high": 95},
        "3m": {"low": 20, "high": 95},
        "7d": {"low": 25, "high": 95},
        "1d": {"low": 25, "high": 95}
    }

    buy_group, sell_group, watch_group, other_group = [], [], [], []

    for item in results:
        stats = item
        lt_hits = 0
        for p_key in ['1y', '6m', '3m']:
            if stats[p_key] and stats[p_key]['pos_pct'] < thresholds[p_key]['low']: lt_hits += 1
        is_lt_buy = lt_hits >= 2
        is_st_buy_7d = stats['7d'] and stats['7d']['pos_pct'] < thresholds['7d']['low'] and stats['7d']['vol'] >= 10.0
        is_st_buy_3m = stats['3m'] and stats['3m']['vol'] > 50.0 and stats['3m']['pos_pct'] < 20.0
        
        # Public.com Strong Buy logic
        pub_rating = stats['data'].get('public_rating')
        is_pub_strong_buy = pub_rating == "Strong Buy"
        
        is_buy = is_lt_buy or is_st_buy_7d or is_st_buy_3m or is_pub_strong_buy
        
        is_sell = False
        is_watch = False
        for p_key in ["1y", "6m", "3m", "7d"]:
            p = stats[p_key]
            if p:
                if p['pos_pct'] > thresholds[p_key]["high"]: is_sell = True
                if (p_key == "3m" and p['vol'] > 50) or (p_key == "7d" and p['vol'] > 20): is_watch = True

        if is_buy: buy_group.append(item)
        if is_sell: sell_group.append(item)
        if is_watch: watch_group.append(item)
        if not (is_buy or is_sell or is_watch): other_group.append(item)

    buy_group.sort(key=lambda x: x['symbol'])
    sell_group.sort(key=lambda x: x['symbol'])
    watch_group.sort(key=lambda x: x['symbol'])
    other_group.sort(key=lambda x: x['symbol'])

    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Stock Multi-Period Analysis</title>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1750px; margin: 0 auto; padding: 10px; background-color: #f4f7f6; }
            h1, h2 { color: #2c3e50; }
            .stock-card { background: white; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 30px; padding: 15px; overflow-x: auto; }
            table { width: 100%; border-collapse: separate; border-spacing: 0; margin-bottom: 20px; background: white; border-radius: 8px; font-size: 0.78em; table-layout: fixed; }
            th, td { padding: 4px 2px; text-align: right; border-bottom: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; word-wrap: break-word; overflow: hidden; }
            
            thead th { background-color: #34495e; color: white; text-align: center; padding: 6px 2px; }
            tbody td:first-child, thead th:first-child { border-left: 1px solid #e2e8f0; }

            /* Period Separators and Shading */
            .period-sep { border-left: 2.5px solid #2c3e50 !important; }
            td.period-alt { background-color: #f8fafc; }
            .period-hdr { border-left: 2.5px solid #1a252f !important; }

            tbody td:first-child { text-align: left; font-weight: bold; background-color: #f9f9f9; }
            
            /* Column Widths */
            .col-sym { width: 75px; }
            .col-price { width: 85px; }
            .col-target { width: 75px; }
            .col-public { width: 85px; }
            .col-option { width: 105px; text-align: left !important; }
            .col-stat { width: 52px; font-size: 0.95em; }
            .col-reason { width: 220px; text-align: left !important; }

            .red-cell { background-color: #ffcccc !important; color: #cc0000; font-weight: bold; }
            .green-cell { background-color: #ccffcc !important; color: #006600; font-weight: bold; }
            .orange-cell { background-color: #ffe5cc !important; color: #e67e22; font-weight: bold; }
            .purple-cell { background-color: #f3e8ff !important; color: #6b21a8; font-weight: bold; }
            .off-hour-text { color: #8e44ad; font-weight: bold; font-size: 0.85em; }
            .watch-reason { font-size: 0.88em; list-style-type: none; padding: 0; margin: 0; text-align: left; }
            .group-header { background-color: #2c3e50; color: white; padding: 10px; margin-top: 40px; border-radius: 8px 8px 0 0; }
            .buy-header { background-color: #e74c3c; }
            .sell-header { background-color: #27ae60; }
            .watch-header { background-color: #e67e22; }
            .chart-container { height: 450px; width: 100%; margin-bottom: 20px; }
            .buy-text { color: #cc0000; font-weight: bold; }
            .sell-text { color: #006600; font-weight: bold; }
            .watch-text { color: #e67e22; font-weight: bold; }
            .charts-row { display: flex; flex-wrap: wrap; gap: 20px; }
            .chart-box { flex: 1; min-width: 600px; }
        </style>
        <script>
            function autoScaleY(gd) {
                const xRange = gd.layout.xaxis.range;
                const data = gd.data[0];
                let minVal = Infinity, maxVal = -Infinity, found = false;
                const minX = new Date(xRange[0]).getTime(), maxX = new Date(xRange[1]).getTime();
                for (let i = 0; i < data.x.length; i++) {
                    const xDate = new Date(data.x[i]).getTime();
                    if (xDate >= minX && xDate <= maxX) {
                        if (data.y[i] < minVal) minVal = data.y[i];
                        if (data.y[i] > maxVal) maxVal = data.y[i];
                        found = true;
                    }
                }
                if (found) {
                    const range = maxVal - minVal;
                    const margin = range === 0 ? 1 : range * 0.1;
                    Plotly.relayout(gd, { 'yaxis.range': [minVal - margin, maxVal + margin] });
                }
            }
        </script>
    </head>
    <body>
        <h1>Stock Analysis: Grouped Watchlist (Including Off-Hours)</h1>
        <p>Generated on: {timestamp}</p>
        {content}
        <script>{charts_js}</script>
    </body>
    </html>
    """

    def render_table(group_results, group_name, header_class):
        if not group_results: return ""
        is_buy_table = "BUY" in group_name
        table_html = f'<div class="group-header {header_class}"><h2>{group_name}</h2></div>'
        table_html += f"""
        <div class="stock-card">
            <table>
                <thead>
                    <tr>
                        <th rowspan="2" class="col-sym">Symbol</th>
                        <th rowspan="2" class="col-price">Price</th>
                        <th rowspan="2" class="col-target">Price Target (SA)</th>
                        <th rowspan="2" class="col-public">Public.com</th>
                        {"<th rowspan='2' class='col-option'>Option Insights</th>" if is_buy_table else ""}
                        <th colspan="5" class="period-hdr">1 Year Period</th>
                        <th colspan="5" class="period-hdr period-alt">6 Month Period</th>
                        <th colspan="5" class="period-hdr">3 Month Period</th>
                        <th colspan="5" class="period-hdr period-alt">7 Day Period</th>
                        <th rowspan="2" class="col-reason period-sep">Watch Reasons</th>
                    </tr>
                    <tr>
                        <th class="col-stat period-sep">High</th><th class="col-stat">Low</th><th class="col-stat">Vol</th><th class="col-stat">Pos%</th><th class="col-stat">Gain%</th>
                        <th class="col-stat period-sep period-alt">High</th><th class="col-stat period-alt">Low</th><th class="col-stat period-alt">Vol</th><th class="col-stat period-alt">Pos%</th><th class="col-stat period-alt">Gain%</th>
                        <th class="col-stat period-sep">High</th><th class="col-stat">Low</th><th class="col-stat">Vol</th><th class="col-stat">Pos%</th><th class="col-stat">Gain%</th>
                        <th class="col-stat period-sep period-alt">High</th><th class="col-stat period-alt">Low</th><th class="col-stat period-alt">Vol</th><th class="col-stat period-alt">Pos%</th><th class="col-stat period-alt">Gain%</th>
                    </tr>
                </thead>
                <tbody>
        """
        for item in group_results:
            sym, stats = item['symbol'], item
            reasons = []
            lt_hits = sum(1 for p in ['3y', '6m', '3m'] if stats[p] and stats[p]['pos_pct'] < thresholds[p]['low'])
            if lt_hits >= 2: reasons.append('<span class="buy-text">BUY (Long Term)</span>: Multi-period low')
            if stats['7d'] and stats['7d']['pos_pct'] < thresholds['7d']['low'] and stats['7d']['vol'] >= 10.0: reasons.append('<span class="buy-text">BUY (Short Term)</span>: 7D Low + Vol')
            if stats['3m'] and stats['3m']['vol'] > 50.0 and stats['3m']['pos_pct'] < 20.0: reasons.append('<span class="buy-text">BUY (Short Term)</span>: 3M Vol Bottom')
            if stats['data'].get('public_rating') == "Strong Buy": reasons.append('<span class="buy-text">BUY</span>: Public.com Strong Buy')

            option_html = ""
            if is_buy_table:
                if stats.get('option_data'):
                    opt = stats['option_data']
                    option_html = f"<td class='col-option'><div style='font-size: 0.85em; text-align: left;'><strong>Ceil: ${stats['current']+opt['premium']:.2f}</strong><br><span style='color: #666;'>Strk: ${opt['strike']:.2f}</span><br><span style='color: #666;'>Cost: ${opt['premium']:.2f}</span><br><small>Exp: {opt['expiry']}</small></div></td>"
                else: option_html = "<td class='col-option'>-</td>"

            price_display = f"${stats['current']:.2f}"
            if stats.get('is_off_hour'): price_display += f"<br><span class='off-hour-text'>LIVE (Off-Hours)</span><br><small style='color:#999'>Close: ${stats['regular_close']:.2f}</small>"

            exp_val = stats.get('expectation_value')
            exp_cls = ""
            if exp_val:
                ratio = exp_val / stats['current']
                if ratio > 1.20: exp_cls = " red-cell"
                elif ratio < 0.80: exp_cls = " green-cell"
            
            exp_val_display = f"${exp_val:.2f}" if exp_val else "-"
            
            # Public.com Rating
            pub_rating = stats['data'].get('public_rating')
            pub_cls = ""
            if pub_rating:
                if "Buy" in pub_rating: pub_cls = " red-cell"
                elif "Sell" in pub_rating: pub_cls = " green-cell"
                elif "Hold" in pub_rating: pub_cls = " orange-cell"
            
            pub_display = pub_rating if pub_rating else "-"

            row_html = f"<tr><td class='col-sym'><a href='#chart-{sym}' style='text-decoration:none; color:inherit;'>{sym} 📈</a></td><td class='col-price'>{price_display}</td><td class='col-target{exp_cls}'>{exp_val_display}</td><td class='col-public{pub_cls}'>{pub_display}</td>{option_html}"
            for p_idx, p_key in enumerate(["1y", "6m", "3m", "7d"]):
                p = stats[p_key]
                alt = " period-alt" if p_idx % 2 == 1 else ""
                sep = " period-sep"
                if p:
                    pos_cls = " red-cell" if p['pos_pct'] < thresholds[p_key]["low"] else (" green-cell" if p['pos_pct'] > thresholds[p_key]["high"] else "")
                    if p['pos_pct'] < thresholds[p_key]["low"] and not any("BUY" in r for r in reasons): reasons.append(f'<span class="buy-text">BUY</span>: {p_key.upper()} Low')
                    elif p['pos_pct'] > thresholds[p_key]["high"]: reasons.append(f'<span class="sell-text">SELL</span>: {p_key.upper()} High')
                    vol_cls = " orange-cell" if ((p_key == "3m" and p['vol'] > 50) or (p_key == "7d" and p['vol'] > 20)) else ""
                    if vol_cls: reasons.append(f'<span class="watch-text">WATCH</span>: {p_key.upper()} Vol')
                    max_cls = " purple-cell" if p['max_cur_pct'] > 20.0 else ""
                    row_html += f"<td class='col-stat{sep}{alt}'>${p['high']:.2f}</td><td class='col-stat{alt}'>${p['low']:.2f}</td><td class='col-stat{vol_cls}{alt}'>{p['vol']:.1f}%</td><td class='col-stat{pos_cls}{alt}'>{p['pos_pct']:.1f}%</td><td class='col-stat{max_cls}{alt}'>+{p['max_cur_pct']:.1f}%</td>"
                else: row_html += f"<td class='col-stat{sep}{alt}'>-</td><td class='col-stat{alt}'>-</td><td class='col-stat{alt}'>-</td><td class='col-stat{alt}'>-</td><td class='col-stat{alt}'>-</td>"
            
            seen_lt_st = any("BUY (" in r for r in reasons)
            unique_reasons = [r for r in list(dict.fromkeys(reasons)) if not ("BUY" in r and "BUY (" not in r and seen_lt_st)]
            row_html += f'<td class="col-reason period-sep"><ul class="watch-reason">{"".join([f"<li>{r}</li>" for r in unique_reasons])}</ul></td></tr>'
            table_html += row_html
        return table_html + "</tbody></table></div>"

    content = render_table(buy_group, "BUY TARGETS (Long/Short Term Opportunities)", "buy-header")
    content += render_table(sell_group, "SELL TARGETS (Near Historical Highs)", "sell-header")
    content += render_table(watch_group, "WATCHLIST (High Volatility)", "watch-header")
    content += render_table(other_group, "OTHER STOCKS", "")

    charts_js, stock_details_html, seen_symbols = "", "", set()
    all_analyzed = buy_group + sell_group + watch_group + other_group
    for item in all_analyzed:
        sym = item['symbol']
        if sym in seen_symbols: continue
        seen_symbols.add(sym)
        summary_parts = []
        for p_key in ["1y", "6m", "3m", "7d"]:
            p = item.get(p_key)
            if p:
                color = "#cc0000" if p['pos_pct'] < thresholds[p_key]["low"] else ("#006600" if p['pos_pct'] > thresholds[p_key]["high"] else "#333")
                summary_parts.append(f"<span style='color:{color}; font-weight:bold;'>{p_key.upper()}: {p['pos_pct']:.1f}% (Gain: +{p['max_cur_pct']:.1f}%)</span>")
        opt_info = f" | <span class='buy-text'>Ceiling: ${item['current']+item['option_data']['premium']:.2f}</span> (Strike: ${item['option_data']['strike']:.2f})" if item.get('option_data') else ""
        summary_html = f"<div style='margin-bottom: 15px; font-size: 0.95em; border-bottom: 1px solid #eee; padding-bottom: 10px;'>" \
                      f"<strong>Current: ${item['current']:.2f}</strong> | {' / '.join(summary_parts)}{opt_info}</div>"

        # Company Header with Link and Description
        comp_info = item['data']
        comp_name = comp_info.get('name', sym)
        comp_site = comp_info.get('website', "")
        comp_desc = comp_info.get('description', "")
        # Limit description to ~200 chars for conciseness
        short_desc = (comp_desc[:200] + '...') if len(comp_desc) > 200 else comp_desc

        site_link = f" | <a href='{comp_site}' target='_blank' style='font-size: 0.6em; color: #3498db;'>{comp_site}</a>" if comp_site else ""

        header_html = f"<div style='margin-bottom: 20px;'> " \
                     f"<h2>{comp_name} ({sym}) 📈 <a href='#' style='font-size: 0.4em; vertical-align: middle;'>[Top]</a>{site_link}</h2>" \
                     f"<p style='font-size: 0.85em; color: #555; font-style: italic; margin-top: -10px;'>{short_desc}</p>" \
                     f"{summary_html}</div>"

        stock_details_html += f"<div id='chart-{sym}' class='stock-card'>{header_html}<div class='charts-row'><div class='chart-box'><h3>Full History</h3><div id='plot-max-{sym}' class='chart-container'></div></div><div class='chart-box'><h3>Intraday (1D incl. Off-Hours)</h3><div id='plot-1d-{sym}' class='chart-container'></div></div></div></div>"

        dates_max, prices_max = [h['date'] for h in comp_info['history']], [round(h['close'], 2) for h in comp_info['history']]
        charts_js += f"""
        var plotMax_{sym} = document.getElementById('plot-max-{sym}');
        Plotly.newPlot(plotMax_{sym}, [{{ x: {json.dumps(dates_max)}, y: {json.dumps(prices_max)}, type: 'scatter', mode: 'lines', name: '{sym} Hist', line: {{color: '#3498db'}} }}], {{
            title: 'Historical', xaxis: {{ title: 'Date', rangeselector: {{ buttons: [ {{ count: 7, label: '7d', step: 'day', stepmode: 'backward' }}, {{ count: 3, label: '3m', step: 'month', stepmode: 'backward' }}, {{ count: 6, label: '6m', step: 'month', stepmode: 'backward' }}, {{ count: 1, label: '1y', step: 'year', stepmode: 'backward' }}, {{ count: 3, label: '3y', step: 'year', stepmode: 'backward' }}, {{ step: 'all', label: 'max' }} ] }}, rangeslider: {{ visible: true }}, type: 'date' }},
            yaxis: {{ title: 'Price', autorange: true }}, margin: {{ t: 40, b: 40, l: 60, r: 20 }}
        }});
        plotMax_{sym}.on('plotly_relayout', function(ed) {{ if (ed['xaxis.range[0]'] || ed['xaxis.range'] || ed['xaxis.autorange']) {{ autoScaleY(plotMax_{sym}); }} }});

        var plot1d_{sym} = document.getElementById('plot-1d-{sym}');
        var data1d_{sym} = {json.dumps(item['intraday'])};

        var regX = [], regY = [], offX = [], offY = [];
        var rangeX = [], rangeUpper = [], rangeLower = [];

        data1d_{sym}.forEach(function(p) {{
            rangeX.push(p.time);
            rangeUpper.push(p.high);
            rangeLower.push(p.low);

            if (p.is_regular) {{
                regX.push(p.time); regY.push(p.price);
                offX.push(p.time); offY.push(null);
            }} else {{
                offX.push(p.time); offY.push(p.price);
                regX.push(p.time); regY.push(null);
            }}
        }});

        Plotly.newPlot(plot1d_{sym}, [
            // Range Area
            {{
                x: rangeX.concat(rangeX.slice().reverse()),
                y: rangeUpper.concat(rangeLower.slice().reverse()),
                fill: 'toself',
                fillcolor: 'rgba(52, 152, 219, 0.15)',
                line: {{color: 'transparent'}},
                name: 'High-Low Range',
                showlegend: true,
                hoverinfo: 'skip'
            }},
            {{ x: regX, y: regY, type: 'scatter', mode: 'lines', name: 'Regular', line: {{color: '#2980b9', width: 2}} }},
            {{ x: offX, y: offY, type: 'scatter', mode: 'lines', name: 'Off-Hours', line: {{color: '#8e44ad', dash: 'dot', width: 2}} }}
        ], {{
            title: 'Intraday (Live Range)', xaxis: {{ title: 'Time', rangeslider: {{ visible: true }} }},
            yaxis: {{ title: 'Price', autorange: true }}, margin: {{ t: 40, b: 40, l: 60, r: 20 }},
            legend: {{ orientation: 'h', y: -0.2 }}
        }});

        """
    full_html = html_template.replace("{timestamp}", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")).replace("{content}", content + stock_details_html).replace("{charts_js}", charts_js)
    with open(output_path, 'w', encoding='utf-8') as f: f.write(full_html)
    print(f"Report generated: {os.path.abspath(output_path)}")

def main():
    if len(sys.argv) < 2:
        ref_dir = Path(__file__).parent.parent / "references"
        tech_path = ref_dir / "tech_stocks.md"
        nontech_path = ref_dir / "nontech_stocks.md"
        manual_path = ref_dir / "manual_stocks.md"
        symbols = []
        for p in [tech_path, nontech_path, manual_path]:
            if p.exists():
                with open(p, "r") as f:
                    content = f.read()
                    symbols.extend(re.findall(r'- ([A-Z]+)', content))
        # Deduplicate while preserving order
        symbols = list(dict.fromkeys(symbols))
    else:
        symbols = sys.argv[1:]

    live_info = fetch_live_info(symbols)
    results = []
    BATCH_SIZE = 50
    BATCH_DELAY = 2  # seconds
    for i, sym in enumerate(symbols):
        if i != 0 and i % BATCH_SIZE == 0:
            batch_num = i // BATCH_SIZE
            print(f"Batch {batch_num} completed, sleeping {BATCH_DELAY}s...")
            time.sleep(BATCH_DELAY)
        print(f"Analyzing {sym}...")
        data = fetch_data(sym)
        if data:
            res = calculate_lows(data, live_info=live_info.get(sym.upper()))
            lt_hits = 0
            if res['1y'] and res['1y']['pos_pct'] < 15:
                lt_hits += 1
            if res['6m'] and res['6m']['pos_pct'] < 15:
                lt_hits += 1
            if res['3m'] and res['3m']['pos_pct'] < 20:
                lt_hits += 1
            is_st_buy = (res['7d'] and res['7d']['pos_pct'] < 25 and res['7d']['vol'] >= 10.0) or (res['3m'] and res['3m']['vol'] > 50.0 and res['3m']['pos_pct'] < 20.0)
            is_pub_strong_buy = data.get('public_rating') == "Strong Buy"
            if lt_hits >= 2 or is_st_buy or is_pub_strong_buy:
                print(f"  > Fetching options for {sym}...")
                res['option_data'] = fetch_option_premium(sym, res['current'])
            else:
                res['option_data'] = None
            results.append(res)
    if results:
        generate_html_report(results)

if __name__ == "__main__":
    main()
